#include <iostream>
#include <ncurses.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <fstream>
#include <signal.h>
#include <queue>
#include <thread>
#include <pthread.h>
#include <termios.h>
#include <stdio.h>
#include <fcntl.h>
#include <cstdlib>
#include <sys/stat.h>//for mkdir and stat struct
#include <unistd.h>//for sleep
#include <ctime>
#include <chrono>
struct shared_vars {
    int ram, rom, core, status;
    shared_vars() : ram(50), rom(50), core(5), status(0) {}
};
