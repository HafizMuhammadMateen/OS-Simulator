#include "head.h"
using namespace std;
struct ProgramInfo {
    int ramTop;
    string programName;
    vector<string> args;
};
key_t key = ftok("shared_mem_key", 1);
int shmid = shmget(key, sizeof(shared_vars), IPC_CREAT | 0666);
shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
queue<ProgramInfo> waitingPrograms;
void* programMonitor(void* arg)
{
    initscr(); //Initialize ncurse
    mvprintw(2, 30, "programMonitor current status : %d", ptr->status);
    cout << "programMonitor current status : " << ptr->status << endl;
      if (!waitingPrograms.empty() && ptr->status > 0 /*any program exited*/) {
        ProgramInfo prog = waitingPrograms.front();
        pid_t childPid = fork();
        if (childPid == 0) {
          shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
          if(ptr->status != 0 && ptr->ram >= prog.ramTop){
            ptr->ram -=prog.ramTop; ptr->rom += prog.ramTop; ptr->core--; ptr->status = 0;
            const char* command[] = {"gnome-terminal", "--", prog.programName.c_str(), NULL};
            execvp(command[0], const_cast<char**>(command));
          }
          exit(0);
        }
        else if (childPid > 0){
            clear(); waitingPrograms.pop(); 
            mvprintw(2, 30, "Memory released by ROM is Occupied by RAM & core 1 used");
            mvprintw(3, 47, "Current RAM : %d%s%d%s%d", ptr->ram, " ROM : ", ptr->rom, " CORE(s) : ", ptr->core);
            mvprintw(4, 30, "Waiting listed program started \"%s%s%d", prog.programName.c_str(), "\" with PID ", childPid);
            mvprintw(3, 35, "Waiting process required ram more RAM!");clear(); 
          return NULL;
        }
        else cerr << "Error: Failed to fork a new process" << endl;
      }
    clear(); endwin(); 
    return NULL;
}
void* programClock(void* args){
  initscr(); // Initialize ncurse
  while(true){
    time_t currentTime = time(NULL);
    struct tm* localTime = localtime(&currentTime);
    mvprintw(1, 40, "Clock: %s", ctime(&currentTime)); 
    refresh();
    this_thread::sleep_for(chrono::milliseconds(500));
  }
  ptr->ram += 5; ptr->core++; ptr->status = 1; //clock exiting and change status to 1
  sleep(1.5); endwin();
  return NULL;
}
int main(int args, char** argv) {
    pthread_t monitorThread;
    //pthread_create(&monitorThread, NULL, programMonitor, NULL);
    if(args != 4){ cerr << "Invalid input: Correct -- [RAM] -- [ROM] -- [CORE(s)].\n"; return -1; }
    ptr->ram = stoi(argv[1]); ptr->rom = stoi(argv[2]); ptr->core = stoi(argv[3]); 
    cout << "\nMain Memory assigned : " << ptr->ram << "\nSecondary Storage assigned : " << ptr->rom 
    << "\nNo. of cores assigned : " << ptr->core << endl; sleep(2);
    system("clear");
    pthread_t clockShow;
    pthread_create(&clockShow, NULL, programClock, NULL);
    ptr->ram -= 5; ptr->core--; //occupied by clock thread
    char choice = ' ';
    refresh();
    while (true) {
      echo();
      mvprintw(5, 45, "[Select an option...]"),mvprintw(6, 45, "[1] Open Notepad"),mvprintw(7, 45,"[2] Simple Restore System");  
      mvprintw(8, 45, "[3] copy file"), mvprintw(9, 45, "[4] delete file\n"); mvprintw(10, 45, "[5] todolist\n");
      //mvprintw(11, 45, "[6] Text editor\n"); mvprintw(12, 45, "[7] Celandar\n"); mvprintw(13, 45, "[8] Move File\n");
      //mvprintw(14, 45, "[9] Calculator\n"); mvprintw(15, 45, "[10] Creating a file\n"); mvprintw(16, 45, "[11] Simple Cleaner\n");
      //mvprintw(17, 45, "[12] Check file info\n"); mvprintw(18, 45, "[13] Simple Backup tool\n"); mvprintw(22, 45, "[0] Exit\n");
      //mvprintw(19, 45, "[14] Image Viewer\n"); 
      mvprintw(20, 45, "[r] Check RAM\n"); mvprintw(21, 45, "[c] execute waiting process\n"); 
      cin >> choice;
        if (choice == '1') {
           if (ptr->core <= 0) {
              clear();
              mvprintw(2, 30, "All cores are busy, adding notepad to the waiting list.");
              ProgramInfo prog;
              prog.programName = "./notepad";
              prog.ramTop = 10;
              prog.args.push_back(to_string(choice));
              waitingPrograms.push(prog);
              ptr->rom -= 10;
              mvprintw(3, 33, "Notepad use 10MB from ROM, remaining ROM : %d", ptr->rom);
            }
            else if(ptr->ram < 10){clear(); mvprintw(2, 0, "Required RAM is 10MB for Notepad, current RAM : %d%s",
            ptr->ram, " please close any other opened process.");}
            else{
              pid_t pid = fork();
              if (pid == 0) {
                shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
                ptr->ram -=10; ptr->core--;
                execlp("gnome-terminal", "gnome-terminal", "--title=Notepad", "--", "./notepad", NULL);
                exit(0);
              }
              else if(pid > 0){
                clear();
                mvprintw(3, 25, "Notepad occupied 10MB RAM and 1 core, Current ram is %d%s%d", ptr->ram,
                " and no of cores : ", ptr->core);              
              }
              else if (pid < 0) {
                cout << "Failed to fork a process." << endl;
                return 1;              
              }
            }
        }
        else if (choice == '2') {
            if (ptr->core <= 0) {
                clear();
                mvprintw(2, 30, "All cores are busy, adding restore system to the waiting list.");
                ProgramInfo prog; 
                prog.programName = "./ssr";
                prog.ramTop = 15;
                prog.args.push_back(to_string(choice));
                waitingPrograms.push(prog);
                ptr->rom -= 15;
                mvprintw(3, 32, "Restore system use 15MB from ROM, remaining ROM : %d", ptr->rom);
            }
            else if(ptr->ram < 15) {clear(); mvprintw(2, 0, "Required RAM is 15MB for Restore system, current RAM : %d%s", ptr->ram, " please close any other opened process.\n");
            }
            else{
              pid_t pid = fork();
              if (pid == 0) {
                shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
                ptr->ram -=15; ptr->core--;
                execlp("gnome-terminal", "gnome-terminal", "--title=Simple_Restore_System", "--", "./ssr", NULL);
                exit(0);
              }
              else if(pid > 0){
                clear();
                mvprintw(3, 25, "Restore system occupied 15MB RAM and 1 core, Current ram is %d%s%d", 
                ptr->ram, " and no of cores : ", ptr->core);
              }
              else if (pid < 0) {
                cout << "Failed to fork a process." << endl;
                return 1;
              }
            }
        }
        else if(choice == '3'){
          clear();
          if (ptr->core <= 0) {                
          mvprintw(2, 30, "All cores are busy, adding copy file to the waiting list.");
                ProgramInfo prog; 
                prog.programName = "./copyfile";
                prog.ramTop = 2;
                prog.args.push_back(to_string(choice));
                waitingPrograms.push(prog);
                ptr->rom -= 2;
                mvprintw(3, 32, "copy file use 2MB from ROM, remaining ROM : %d", ptr->rom);
            }
            else if(ptr->ram < 5) {clear(); mvprintw(2, 0, "Required RAM is 2MB for copy file, current RAM : %d%s", ptr->ram, " please close any other opened process.\n");
            }
            else{
              pid_t pid = fork();
              if (pid == 0) {
                shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
                ptr->ram -=2; ptr->core--;
                execlp("gnome-terminal", "gnome-terminal", "--title=copyfile", "--", "./copyfile", NULL);
                exit(0);
              }
              else if(pid > 0){
                clear();
                mvprintw(3, 25, "copy file occupied 2MB RAM and 1 core, Current ram is %d%s%d", 
                ptr->ram, " and no of cores : ", ptr->core);
              }
              else if (pid < 0) {
                cout << "Failed to fork a process." << endl;
                return 1;
              }
            }

        }
        else if(choice == '4'){
          clear();
          if (ptr->core <= 0) {
                mvprintw(2, 30, "All cores are busy, adding delete file to the waiting list.");
                ProgramInfo prog; 
                prog.programName = "./deletefile";
                prog.ramTop = 5;
                prog.args.push_back(to_string(choice));
                waitingPrograms.push(prog);
                ptr->rom -= 5;
                mvprintw(3, 32, "delete use 5MB from ROM, remaining ROM : %d", ptr->rom);
            }
            else if(ptr->ram < 5) {clear(); mvprintw(2, 0, "Required RAM is 5MB for delete file, current RAM : %d%s", ptr->ram, " please close any other opened process.\n");
            }
            else{
              pid_t pid = fork();
              if (pid == 0) {
                shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
                ptr->ram -=5; ptr->core--;
                execlp("gnome-terminal", "gnome-terminal", "--title=deletefile", "--", "./deletefile", NULL);
                exit(0);
              }
              else if(pid > 0){
                clear();
                mvprintw(3, 25, "deletefile occupied 5MB RAM and 1 core, Current ram is %d%s%d", 
                ptr->ram, " and no of cores : ", ptr->core);
              }
              else if (pid < 0) {
                cout << "Failed to fork a process." << endl;
                return 1;
              }
            }
        }
        else if(choice == '5'){
          clear();
          if (ptr->core <= 0) {
                mvprintw(2, 30, "All cores are busy, adding todolist to the waiting list.");
                ProgramInfo prog; 
                prog.programName = "./todolist";
                prog.ramTop = 5;
                prog.args.push_back(to_string(choice));
                waitingPrograms.push(prog);
                ptr->rom -= 5;
                mvprintw(3, 32, "todolist use 5MB from ROM, remaining ROM : %d", ptr->rom);
            }
            else if(ptr->ram < 5) {clear(); mvprintw(2, 0, "Required RAM is 5MB for todolist, current RAM : %d%s", ptr->ram, " please close any other opened process.\n");
            }
            else{
              pid_t pid = fork();
              if (pid == 0) {
                shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
                ptr->ram -=5; ptr->core--;
                execlp("gnome-terminal", "gnome-terminal", "--title=todolist", "--", "./todolist", NULL);
                exit(0);
              }
              else if(pid > 0){
                clear();
                mvprintw(3, 25, "todolist occupied 5MB RAM and 1 core, Current ram is %d%s%d", 
                ptr->ram, " and no of cores : ", ptr->core);
              }
              else if (pid < 0) {
                cout << "Failed to fork a process." << endl;
                return 1;
              }
            }
        }
        else if(choice == 'c'){
            pthread_create(&monitorThread, NULL, programMonitor, NULL);
            //pthread_join(monitorThread, NULL);
        }
        else if(choice == 'r'){
          clear();
          mvprintw(3, 20, "Current RAM is : %d%s%d%s%d%s%d", ptr->ram, ", Current ROM is : ", ptr->rom,
          ", Current CORE(s) available : ", ptr->core, ", Exited program status : ", ptr->status);
        }
        else if (choice == '0') {
          clear();
          mvprintw(2, 42, "You are going to close this os!");          
          mvprintw(3, 35, "press [0] to make sure, or any other key to continue..."); 
          cin >> choice;
          if(choice == '0'){
            system("clear"); cout << "\n\n\n\n\n\n\n\n\n\t\t\t\t\tThanks for visiting my os.\n"; sleep(2.5); system("clear");
            ptr->ram = 0; ptr->rom = 0; ptr->core = 0; ptr->status = 0; exit(0);
          }
          else{
            clear(); mvprintw(3, 42, "Welcome back to my os!");  
          }
        }
        else {
          clear(); mvprintw(3, 45, "Invalid choice.");
        }
    }
    pthread_join(monitorThread, NULL);
    pthread_join(clockShow, NULL);
    shmdt(ptr); shmctl(shmid, IPC_RMID, NULL);
    return 0;
}
