#include "head.h"
using namespace std;
int main() 
{
    key_t key = ftok("shared_mem_key", 1);
    int shmid = shmget(key, sizeof(shared_vars), IPC_CREAT | 0666);
    shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
    initscr();    // Initialize ncurses
    cbreak();   // Disable line buffering
    noecho();   // Disable echoing of typed characters
    curs_set(0);  // Hide the cursor
    nodelay(stdscr, true); // Set getch() to non-blocking mode
    while (true) {
        clear();
        time_t currentTime = time(NULL);
        struct tm* localTime = localtime(&currentTime);
        mvprintw(1, 0, "Clock: %s", ctime(&currentTime)); 
        refresh();
        this_thread::sleep_for(chrono::milliseconds(500));
        int ch = getch(); // Read the key that was pressed
        if (ch != ERR) {
          echo();
          mvprintw(3, 0, "ClockShow releasing 5MB ram and 1 core...");
          mvprintw(4, 0, "ClockShow set exiting programs status to %d.", ptr->status);
          mvprintw(5, 0, "ClockShow releasing 5MB RAM and 1 core...");
          ptr->ram += 5; ptr->core++; ptr->status = 1; //clock exiting and change status to 1
          sleep(1.5); exit(0);
        }
    }
    endwin(); // End ncurses
    return 0;
}
