#include <stdio.h>

int main() {
    float num1, num2, result;
    char operation;

    // Input first number
    printf("Enter first number: ");
    scanf("%f", &num1);

    // Input operation
    printf("Enter operation (+, -, *, /): ");
    scanf(" %c", &operation);

    // Input second number
    printf("Enter second number: ");
    scanf("%f", &num2);

    // Perform operation and display result
    switch (operation) {
        case '+':
            result = num1 + num2;
            printf("Result: %f\n", result);
            break;
        case '-':
            result = num1 - num2;
            printf("Result: %f\n", result);
            break;
        case '*':
            result = num1 * num2;
            printf("Result: %f\n", result);
            break;
        case '/':
            if (num2 != 0) {
                result = num1 / num2;
                printf("Result: %f\n", result);
            } else {
                printf("Error: Division by zero!\n");
            }
            break;
        default:
            printf("Error: Invalid operation!\n");
    }

    return 0;
}
