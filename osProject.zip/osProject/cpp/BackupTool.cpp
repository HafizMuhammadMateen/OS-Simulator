#include <iostream>
#include <fstream>
#include <ctime>

using namespace std;

int main() {
    time_t now = time(0);
    char* dt = ctime(&now);
    string fileName = "backup_" + string(dt) + ".txt";
    ofstream backupFile(fileName.c_str());
    backupFile << "System backup created on " << dt << endl;
    backupFile.close();
    cout << "Backup successful!" << endl;
    return 0;
}
