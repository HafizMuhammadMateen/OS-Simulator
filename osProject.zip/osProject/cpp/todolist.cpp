#include "head.h"
using namespace std;

struct TodoItem {
    string task;
    string dueDate;
};

void printReminder(const TodoItem& item) {
    cout << "Task: " << item.task << endl;
    cout << "Due Date: " << item.dueDate << endl;
}

int main() {

    key_t key = ftok("shared_mem_key", 1);
    int shmid = shmget(key, sizeof(shared_vars), IPC_CREAT | 0666);
    shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);

    const int MAX_TASKS = 10;
    TodoItem todoList[MAX_TASKS];
    int numTasks = 0;

    while (true) {
        cout << "Press 1 to add a task." << endl;
        cout << "Press 0 to exit." << endl;
        cout << "Enter choice: ";
        int choice;
        cin >> choice;
        cin.ignore(); // Ignore the remaining newline character from the previous input

        if (choice == 1) {
            if (numTasks < MAX_TASKS) {
                cout << "Enter a task (or 'quit' to exit): ";
                string task;
                getline(cin, task);
                if (task == "quit") {
                    break;
                }
                cout << "Enter the due date for the task (YYYY-MM-DD): ";
                string dueDate;
                getline(cin, dueDate);
                todoList[numTasks] = {task, dueDate};
                numTasks++;
            } else {
                cout << "Task limit reached. Cannot add more tasks." << endl;
            }
        } else if (choice == 0) {
               ptr->ram +=10; ptr->core++; ptr->status = 5;//todolist exiting and change status to 1
                cout << "todolist set exiting programs status to " << ptr->status << ".\n";
                cout << "todolist releasing 5MB RAM and 1 core...\n";
                sleep(1.5); exit(0);
        } else {
            cout << "Invalid choice." << endl;
        }
    }

    for (int i = 0; i < numTasks; i++) {
        cout << "Reminder for task " << (i + 1) << ":" << endl;
        printReminder(todoList[i]);
        cout << endl;
    }

    return 0;
}
