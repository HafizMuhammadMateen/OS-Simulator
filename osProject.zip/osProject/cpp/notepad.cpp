#include "head.h"
using namespace std;
int main() {
    cout << "Welcome to Notepad!" << endl;
    int choice; string filename;
    key_t key = ftok("shared_mem_key", 1);
    int shmid = shmget(key, sizeof(shared_vars), IPC_CREAT | 0666);
    shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
    do {
        cout << "\nChoose an option:" << endl;
        cout << "1. Create a new file" << endl;
        cout << "2. Open an existing file" << endl;
        cout << "0. Exit" << endl;
        cin >> choice;
        switch (choice) {
            case 0:
                //sem_init(&sem1, 1, 1);
                //sem_init(&sem2, 1, 0);
                // Use the semaphore variables to synchronize access to the shared memory segment
                //sem_wait(&sem1);
                //shm->data = 1;
                //cout << "sign set to 1.\n";
                //sem_post(&sem2);
                //shmdt(shm);//Detach from the shared memory segment
                ptr->ram +=10; ptr->core++; ptr->status = 1;//notepad exiting and change status to 1
                cout << "Notepad set exiting programs status to " << ptr->status << ".\n";
                cout << "Notepad releasing 10MB RAM and 1 core...\n";
                sleep(1.5); exit(0);
            case 1:
                cout << "Enter filename: ";
                cin >> filename;
                {
                    ofstream outfile(filename);
                    if (!outfile) {
                        cout << "Error creating file " << filename << endl;
                    }
                    else {
                        cout << "File " << filename << " created successfully." << endl;
                        outfile.close();
                    }
                }
                break;
            case 2:
                cout << "Enter filename: ";
                cin >> filename;
                {
                 ifstream infile(filename);
                 if (!infile) {
                  cout << "Error opening file " << filename << endl;
                 }
                 else {
                   string line;
                   cout << "File " << filename << " opened successfully." << endl;
                   cout << "Contents of the file:" << endl;
                   while (getline(infile, line)) {
                     cout << line << endl;
                   }
                   infile.close();
                   char edit_choice;
                   cout << endl << "Do you want to edit this file? (Y/N) ";
                   cin >> edit_choice;
                   if (edit_choice == 'Y' || edit_choice == 'y') {
                    fstream outfile(filename, ios::app);
                    if (!outfile) {
                      cout << "Error opening file " << filename << " for writing." << endl;
                    }
                    else {
                      string new_line = "";
                      cout << "Enter text to add to the file. Write 'save' to save and exit." << endl;
                      while (new_line != "\\save") {
                        outfile << new_line << endl;
                        getline(cin, new_line);
                      }
                      if (new_line == "\\save") {                             
                        cout << "File " << filename << " saved." << endl;
                        outfile.close(); 
                      }
                    }
                  }
                }
              }
              break;
            default:
                cout << "Invalid choice. Try again." << endl;
                break;
        }
    } while (choice != 3);
    shmdt(ptr);
    shmctl(shmid, IPC_RMID, NULL);
    return 0;
}
