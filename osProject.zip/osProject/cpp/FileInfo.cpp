#include <iostream>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <ctime>

using namespace std;

int main() {
    // Get the filename from the user
    string filename;
    cout << "Enter the filename: ";
    cin >> filename;

    // Check if the file exists
    struct stat buffer;
    if (stat(filename.c_str(), &buffer) != 0) {
        cerr << "Error: " << filename << " does not exist." << endl;
        return 1;
    }

    // Print information about the file
    cout << "File name: " << filename << endl;
    cout << "File size: " << buffer.st_size << " bytes" << endl;
    cout << "Creation time: " << ctime(&buffer.st_ctime);
    cout << "Modification time: " << ctime(&buffer.st_mtime);
    sleep(5);
    return 0;
}

