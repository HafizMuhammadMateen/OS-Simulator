#include "head.h"
using namespace std;

int main() {
    int choice; string filename;
    key_t key = ftok("shared_mem_key", 1);
    int shmid = shmget(key, sizeof(shared_vars), IPC_CREAT | 0666);
    shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
    cout << "Press 1 to copy a file." << endl;
    cout << "Press 0 to exit." << endl;

    while (true) {
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            string source_path, dest_path;
            cin.ignore(); // Ignore the remaining newline character from the previous input

            cout << "Enter the source file path: ";
            getline(cin, source_path);

            cout << "Enter the destination file path: ";
            getline(cin, dest_path);

            // Open the source file for reading
            ifstream source_file(source_path, ios::binary);
            if (!source_file) {
                cout << "Error opening source file" << endl;
                return 1;
            }

            // Open the destination file for writing
            ofstream dest_file(dest_path, ios::binary);
            if (!dest_file) {
                cout << "Error opening destination file" << endl;
                return 1;
            }

            // Read from the source file and write to the destination file
            char buffer[1024];
            while (source_file.read(buffer, sizeof(buffer))) {
                dest_file.write(buffer, source_file.gcount());
            }

            // Close the files
            source_file.close();
            dest_file.close();

            cout << "File copied successfully" << endl;
        } else if (choice == 0) {
            ptr->ram +=5; ptr->core++; ptr->status = 3;//copyfile and change status to 3
            cout << "copyfile set exiting programs status to " << ptr->status << ".\n";
            cout << "copyfile 5MB RAM and 1 core...\n";
            sleep(1.5); exit(0);
        } else {
            cout << "Invalid choice." << endl;
        }
    }

    return 0;
}
