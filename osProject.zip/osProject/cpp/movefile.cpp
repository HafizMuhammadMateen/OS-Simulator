#include <iostream>
#include <fstream>
#include <cstdio>
using namespace std;
int main()
{
    string srcfilepath,dstfilepath;
    cout<<"Source File path:";
        getline(cin,srcfilepath);
    cout<<"Destination file path:";
        getline(cin,dstfilepath);
    ifstream srcfile(srcfilepath,ios::binary);
    if(!srcfile.is_open())
    {
        cerr << "Error to open source file"<<endl;
        return 1;
    }
    ofstream dstfile(dstfilepath,ios::binary);
    if (!dstfile.is_open()) 
    {
        cerr<<"Error to open destination file"<<endl;
        return 1;
    }
    char buffer[1024];
    while(srcfile.read(buffer,sizeof(buffer))) 
    {
        dstfile.write(buffer,sizeof(buffer));
    }
    streamsize rem_bytes =srcfile.gcount();
    if (rem_bytes>0) 
    {
        dstfile.write(buffer,rem_bytes);
    }
    srcfile.close();
    dstfile.close();
    if(remove(srcfilepath.c_str())!=0) 
    {
        cerr<<"Cannot delete source file"<<endl;
        return 1;
    }
    cout<<"File has been moved successfully."<<endl;
    return 0;
}

