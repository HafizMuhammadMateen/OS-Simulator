#include <iostream>
#include <iomanip>
#include <ctime>
using namespace std;
int main() {
    time_t now=time(0);
    tm*local_time=localtime(&now);
    int year=local_time->tm_year+1900;
    int month=local_time->tm_mon+1;
    cout<<"   " << year << " / " << setw(2) << setfill('0') <<month<<endl;
    cout << "Su Mo Tu We Th Fr Sa"<<endl;
    tm date={0,0,0,1,month-1,year-1900};
    time_t start=mktime(&date);
    int weekday=localtime(&start)->tm_wday;
    for (int i=0;i<weekday;i++)
    {
        cout<<"   ";
    }
    int days_in_month = 31;
    if(month==4||month==6||month==9||month==11) 
    {
        days_in_month=30;
    }
    else if(month==2) 
    {
        if(year%4==0&&(year%100!=0||year%400==0)) 
        {
            days_in_month=29;
        }
        else 
        {
            days_in_month=28;
        }
    }
    for (int i=1;i<=days_in_month;i++)
    {
        cout<<setw(2)<<i<<" ";
        if((i+weekday)%7==0) 
        {
            cout<<endl;
        }
    }
    cout<<endl;
    return 0;
}

