#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main()
{
    string file_name;
    cout<<"Create or open file:";
    cin>>file_name;
    fstream file(file_name,ios::in|ios::out| ios::trunc);
    if (!file.is_open())
    {
        cerr<<"cannot  open file: "<<file_name<<endl;
        return 1;
    }
    cout<<"File"<< file_name<<"file has been open successfully"<<endl;
    string line;
    while(getline(file,line))
    {
        cout<<line<<endl;
    }
    string input;
    cout<<"Type text on file and to close press exit:"<<endl;
    while(getline(cin,input))
    {
        if (input =="exit")
        {
            break;
        }
        file<<input<<endl;
    }
    cout <<"save and close successfully:"<<endl;
    file.close();
    return 0;
}

