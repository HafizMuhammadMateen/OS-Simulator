#include "head.h"
using namespace std;
string get_file_path() {
    char cwd[1024];
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        string path = cwd;
        path += "/.trash/";
        return path;
    } else {
        cerr << "Error: Could not get current working directory." << endl;
        exit(EXIT_FAILURE);
    }
}
void create_trash_directory() {
    string path = get_file_path();
    struct stat st;
    if (stat(path.c_str(), &st) == -1) { mkdir(path.c_str(), 0700); }
}
void trash_file(string filename) {
    string old_path = filename;
    string new_path = get_file_path() + filename;
    ifstream old_file(old_path.c_str());
    if (old_file.good()) {
        old_file.close();
        rename(old_path.c_str(), new_path.c_str());
        cout << "File '" << filename << "' has been moved to trash." << endl;
    }
    else cerr << "Error: Could not move file '" << filename << "' to trash." << endl;
}
void restore_file(string filename) {
    string old_path = get_file_path() + filename;
    string new_path = filename;
    ifstream old_file(old_path.c_str());
    if (old_file.good()) {
        old_file.close();
        rename(old_path.c_str(), new_path.c_str());
        cout << "File '" << filename << "' has been restored from trash." << endl;
    }
    else cerr << "Error: Could not restore file '" << filename << "' from trash." << endl;
}
int main() {
    create_trash_directory();
    int choice; string filename;
    key_t key = ftok("shared_mem_key", 1);
    int shmid = shmget(key, sizeof(shared_vars), IPC_CREAT | 0666);
    shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);
    while (true) {
        cout << "Please select an option:" << endl;
        cout << "1. Trash a file" << endl;
        cout << "2. Restore a file" << endl;
        cout << "0. Exit" << endl;
        cin >> choice;
        switch (choice) {
            case 0:
                ptr->ram += 15; ptr->core++; ptr->status = 2;//ssr exiting and change status to 1
                cout << "Restore system set exiting programs status to " << ptr->status << ".\n";
                cout << "Restore system releasing 15MB RAM and 1 core...\n";
                sleep(1.5); exit(0);
            case 1:
                cout << "Enter the filename to trash: ";
                cin >> filename;
                trash_file(filename);
                break;
            case 2:
                cout << "Enter the filename to restore: ";
                cin >> filename;
                restore_file(filename);
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    }
    return 0;
}
