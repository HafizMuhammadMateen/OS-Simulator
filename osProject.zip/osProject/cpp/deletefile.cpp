#include "head.h"
using namespace std;
int main() {

    key_t key = ftok("shared_mem_key", 1);
    int shmid = shmget(key, sizeof(shared_vars), IPC_CREAT | 0666);
    shared_vars* ptr = (shared_vars*) shmat(shmid, NULL, 0);

    cout << "Press 1 to delete a file." << endl;
    cout << "Press 0 to exit." << endl;

    int choice;
    while (true) {
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            string file_path;
            cin.ignore(); // Ignore the remaining newline character from the previous input

            cout << "Enter the file path and name: ";
            getline(cin, file_path);

            // Convert the file path to a C-style string
            const char* c_file_path = file_path.c_str();

            // Call the remove() function to delete the file
            int result = remove(c_file_path);

            // Check if the file was successfully deleted
            if (result != 0) {
                cout << "Error deleting file" << endl;
            } else {
                cout << "File successfully deleted" << endl;
            }
        } else if (choice == 0) {
            ptr->ram +=5; ptr->core++; ptr->status = 4;//notepad exiting and change status to 1
            cout << "deletefile set exiting programs status to " << ptr->status << ".\n";
            cout << "deletefile releasing 5MB RAM and 1 core...\n";
            sleep(1.5); exit(0);
        } else {
            cout << "Invalid choice." << endl;
        }

        cin.ignore(); // Ignore the remaining newline character from the previous input
    }

    return 0;
}
