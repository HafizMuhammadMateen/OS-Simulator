#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
    // Load the image file from the command line argument
    if (argc < 2) {
        cout << "Usage: imageviewer <image file>\n";
        return -1;
    }

    string filename(argv[1]);

    ifstream file(filename);

    if (!file) {
        cout << "Error: Unable to open image file\n";
        return -1;
    }

    // Load the image data into a string
    stringstream buffer;
    buffer << file.rdbuf();

    // Display the image using the "display" command
    string cmd = "display -resize 50% " + filename;
    system(cmd.c_str());

    return 0;
}
