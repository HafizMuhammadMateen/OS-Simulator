#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void clearConsole() {
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
    system("cls");
#else
    system("clear");
#endif
}

void removeTempFiles() {
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
    // Windows specific code to remove temporary files
    // Replace with appropriate command or file deletion logic for your system
    printf("Removing temporary files on Windows...\n");
#else
    // Linux/Unix specific code to remove temporary files
    // Replace with appropriate command or file deletion logic for your system
    printf("Removing temporary files on Linux/Unix...\n");
#endif
    // Placeholder code to simulate file deletion
    printf("Deleted 10 temporary files.\n");
}

int main() {
    clearConsole();
    printf("Simple System Cleaner\n");
    printf("---------------------\n");
    removeTempFiles();
    printf("\nCleanup completed successfully!\n");
    return 0;
}
