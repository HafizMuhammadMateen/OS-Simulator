#include <stdio.h>

int main() {
    FILE *file; // Declare a file pointer
    file = fopen("example.txt", "w"); // Open a file in write mode

    if (file == NULL) {
        printf("Failed to create the file!\n");
        return 1;
    }

    fprintf(file, "Hello, World!"); // Write content to the file
    fclose(file); // Close the file

    printf("File created successfully!\n");

    return 0;
}

